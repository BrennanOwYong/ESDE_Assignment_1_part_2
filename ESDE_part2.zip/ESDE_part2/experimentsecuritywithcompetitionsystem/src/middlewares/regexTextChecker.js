module.exports.findMaliciousCode = (req, res, next) => {
    var stringChecker = new RegExp(`^[a-zA-Z0-9 ',\.]+$`);
    let designTitle = req.body.designTitle;
    let designDescription = req.body.designDescription;
    console.log(designDescription, designTitle)
    if (stringChecker.test(designTitle) && stringChecker.test(designDescription)) {
        console.log("String is allowed")
        next()
    } else {
        res.status(403).json({ message: "Unauthorized text input" })
    }
}

module.exports.checkPasswordEntry = (req, res, next) => {
    var allowedPassword = new RegExp(`^[a-zA-Z0-9 \.!@#\$%\^&\*\(\)-_=\+]+$`);
    var password = req.body.password;
    var username = req.body.fullName;
    var email = req.body.email;
    if (password.length < 12 || !allowedPassword.test(password) || password.indexOf("password") >= 0 || password.toLowerCase().indexOf(username.toLowerCase()) >= 0 || charChecker(password) || password.toLowerCase().indexOf(email.substring(0, email.indexOf("@"))) >= 0) {
        res.status(403).json({ message: "Password is too weak." })
    } else {
        next();
    }
}

function charChecker(password) {
    var upperCaseChecker = 0;
    var lowerCaseChecker = 0;
    var numChecker = 0;
    var specialCharacterChecker = 0;
    var specialCharacterArray = ["!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "-", "_", "=", "+"];
    for (var i = 0; i < password.length; i++) {
        var c = password.charAt(i)
        if (!isNaN(c)) { numChecker++; }
        if (c == c.toUpperCase()) { upperCaseChecker++; }
        if (c == c.toLowerCase()) { lowerCaseChecker++; }
        if (specialCharacterArray.indexOf(c) > 0) { specialCharacterChecker++; }
    }
    if (lowerCaseChecker > 1 && upperCaseChecker > 1 && numChecker > 1 && specialCharacterChecker > 1) {
        return true
    } else {
        return false
    }
}